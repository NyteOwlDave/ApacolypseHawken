
/////////////////////////////////////////////////////////////////////////////
//
// kaboom.js - Generate Explosion Sprites
//   NyteOwl, 2017-NOV-11
//
/////////////////////////////////////////////////////////////////////////////

Project.register('kaboom.js')

const Kaboom = {
	EXPLODE_SIZE: 80,
	EXPLODE_FRAMES: 64,
	frame: [],
	createFrames: (()=>{
		const spr = Kaboom
		const create = ((a,s,n)=>{
			if (n<1) return
			a.push(new ImageData(s,s))
			create(a,s,n-1)
		})
		create(
			spr.frame,
			spr.EXPLODE_SIZE,
			spr.EXPLODE_FRAMES
		)
		console.log(`Created ${spr.EXPLODE_FRAMES} frames`)
	}),
	getpixel: ((i,x,y)=>{
		const spr = Kaboom, w = spr.EXPLODE_SIZE
		const k = 4*(y*w+x)
    const r = spr.frame[i].data[k  ]
    const g = spr.frame[i].data[k+1]
    const b = spr.frame[i].data[k+2]
    const a = spr.frame[i].data[k+3]
    return [r,g,b,a]
	}),
	putpixel: ((i,x,y,c)=>{
		const spr = Kaboom, w = spr.EXPLODE_SIZE
		const k = 4*(y*w+x)
		spr.frame[i].data[k]   = c[0]
		spr.frame[i].data[k+1] = c[1]
		spr.frame[i].data[k+2] = c[2]
		spr.frame[i].data[k+3] = c[3]
	}),
	createExplosions: (()=>{
    function mapColor(c) {
      if (c<2) return [0,0,0,0]
      if (c>255) c = 255
      const s = htmlFirePalette.color[c]
      const clr = PixelBuffer.parseHTMLColor(s)
      return [clr.r,clr.g,clr.b,255]
    }
		const spr = Kaboom
		// Frame count
		const frames = spr.EXPLODE_FRAMES
		// Frame size (width and height)
		const size = spr.EXPLODE_SIZE
    // Allocate fire pixel buffer
    const buffer = new Uint8Array(size*size)
    // Get fire pixel (8-bit)
    function get(x,y) {
      return buffer[y*size+x]
    }
    // Set fire pixel (8-bit)
    function put(x,y,n) {
      buffer[y*size+x]=n
    }
		// Create frame buffers
    spr.createFrames()
    // Center of frame
		const ctr = size>>1
		// Number of hot spots
		const HOTSPOTS = 64, hot = []
		// Create a new hot spot
		const newSpot = (c=>{
			return ({
				x:  (c + 12*Math.random() - 6), 
				y:  (c + 12*Math.random() - 6),
				xc: (Math.random() - 0.5), 
				yc: (Math.random() - 0.5)
			})		
		})
		// Initialize Hotspot map
		var spot
		for (spot=0; spot<HOTSPOTS; spot++) {
			let f = newSpot(ctr)
			// console.log(JSON.stringify(f))
			hot.push(f)
		}
		// For each sprite (animation frame)
		var frame
		for (frame=0; frame<frames; frame++) {
			// Calculate axis and rise
			const axis = frames>>2
			const rise = 128/axis
			// Color delta @ the hotspot
			var dc = (frame<axis) ? 
				(frame * rise) :
				(frames - frame + 8)
			// For each hotspot
			for (spot=0; spot<HOTSPOTS; spot++) {
				// Get centerpoint for this hotspot
				var hot_x = Math.floor(hot[spot].x)
				var hot_y = Math.floor(hot[spot].y)
				// We'll scan horizontally from -6 to +6 pixels from hot_x
				var x
				for (x=-6; x<=6; x++) {
					// Offset horizontally from hotspot center
					var xx = hot_x + x
					// We'll scan vertically from -6 to +6 pixels from hot_y
					var y
					for (y=-6; y<=6; y++) {
						// Offset vertically from hotspot center
						var yy = hot_y + y
						// If pixel is within the sprite
						if ((xx>=0) &&
							  (yy>=0) &&
							  (xx<size) &&
							  (yy<size)) {
							// Get the falloff shift factor
							var falloff_shift = Math.floor(
								(Math.abs(x)+Math.abs(y)) / 3
							)
							// Read pixel at (xx,yy) for this frame
							//  and adjust color according to
							//  color delta and falloff shift factor.
							var pel = get(xx,yy) + (dc >> falloff_shift)
              if (pel > 255) pel = 255
							// Write new color (clamped to max)
              put(xx,yy,pel)
							// Write color as ImageData pixel (32-bpp)
              spr.putpixel(frame,xx,yy,mapColor(pel))
						}
					}
				}
				// Move the hotspot (for the next frame)
				hot[spot].x += hot[spot].xc
				hot[spot].y += hot[spot].yc
			}
		}
    delete hot
    delete buffer
	}),
	drawFrame: ((exp)=>{
		const o = Kaboom
		const frames = o.EXPLODE_FRAMES
		const size = o.EXPLODE_SIZE
		if ((exp.i<0)||(exp.i>frames)) return
    const canvas = document.createElement('canvas')
    canvas.style.position = 'absolute'
    canvas.style.left = exp.x+'px'
    canvas.style.top  = exp.y+'px'
    canvas.w = size
    canvas.h = size
		const gfx = canvas.getContext('2d')
    gfx.putImageData(o.frame[exp.i],0,0)
    o.removeCanvas(exp)
    exp.canvas = canvas
    document.body.appendChild(canvas)
	}),
  newExplosion: ((x,y)=>{
		const o = Kaboom
    const half = o.EXPLODE_SIZE/2
    return {
      'x': (x - half),
      'y': (y - half),
      'i': 0,
      'canvas': null
    }
  }),
  removeCanvas: ((exp)=>{
    if (exp.canvas && (exp.canvas.parentElement===document.body)) {
      document.body.removeChild(exp.canvas)
      exp.canvas = null
    }
  })
}

// console.log('Explosion loaded...')


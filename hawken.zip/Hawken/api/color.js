
/*

  color.js -- color and pixel functions
  Dave Wellsted, NyteOwl Computer Software
  2017-NOV-05
  
*/

Project.register('color.js')

//-----------------------------------
// JS Colors - PART 1 of 4 
//-----------------------------------

// Create a color object
function MakeColor(r,g,b) {
  return {
    "R" : r,
    "G" : g,
    "B" : b
  }
}

// Convert RGB color to grey-scale equivalent
function ColorToGreyScale(c) {
    return {
      "R": Math.floor(c.R * 0.2989),
      "G": Math.floor(c.G * 0.5870),
      "B": Math.floor(c.B * 0.1140)
    }
}

//-----------------------------------
// JS Colors - PART 2 of 4 
//-----------------------------------

// Gamma function for color correction
function Gamma(n,max,gamma) {
  return (max * Math.pow(n/max, 1/gamma))
}

// Create grey-scale palette
function GreyPalette() {
  const pal = []
  let x
  for (x=0; x<256; x++) {
    const luma = Gamma(x,255,1.2)
    pal.push(MakeColor(luma,luma,luma))
  }
  return pal
} 

//-----------------------------------
// JS Colors - PART 3 of 4 
//-----------------------------------

// Read pixel color from ImageData
function GetPixel(img,x,y) {
  const i = 4*(y*img.width+x)
  const r = img.data[i]
  const g = img.data[i+1]
  const b = img.data[i+2]
  return MakeColor(r,g,b)
}

// Write pixel color to ImageData
function SetPixel(img,x,y,c) {
  const i = 4*(y*img.width+x)
  img.data[i]=c.R
  img.data[i+1]=c.G
  img.data[i+2]=c.B
  img.data[i+3]=255    
}

//-----------------------------------
// JS Colors - PART 4 of 4 
//-----------------------------------

// Do nearest match for palette color
function GetNearestColor(pal,r,g,b) {
  let y,i=0,best=0x7FFFFFFF
  for (y=0; y<256; y++) {
    let rdiff = r - pal[y].R
    let gdiff = g - pal[y].G
    let bdiff = b - pal[y].B
    let diff = rdiff*rdiff 
             + gdiff*gdiff 
             + bdiff*bdiff
    if (diff < best) {
      i = y
      best = diff
    }
  }
  return i
}



/*

  loadimg.js -- image file loader
  Dave Wellsted, NyteOwl Computer Software
  2017-NOV-05
  
*/

Project.register('loadimg.js')

const ImageLoader = {
  canvas: null,
  gfx: null
}

ImageLoader.init = function() {
  let canvas = ImageLoader.canvas;
  if (canvas) return canvas;
  canvas = document.createElement('canvas');
  canvas.style.visibility = 'hidden';
  ImageLoader.canvas = canvas;
  ImageLoader.gfx = canvas.getContext('2d');
  return canvas;
}

ImageLoader.load = function(url,onload) {
  const me = ImageLoader;
  const canvas = me.init();
  const gfx = me.gfx;
  let data = null;
  const img = new Image();
  function setCanvasSize(w,h) {
    canvas.width  = w;
    canvas.height = h;
  }
  function loaded() {
    createImageBitmap(
      img, 0, 0,
      img.naturalWidth,
      img.naturalHeight
    ).then(bmp=>{
      const w = bmp.width;
      const h = bmp.height;
      setCanvasSize(w,h);
      gfx.drawImage(bmp,0,0);
      data = gfx.getImageData(0,0,w,h);
      if ('function'===(typeof onload)) {
        onload(data);
      }
    });
  }
  img.onload = loaded;
  img.src = url;
  return me;
}


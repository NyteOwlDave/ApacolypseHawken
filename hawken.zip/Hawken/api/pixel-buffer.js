
/*

	File:		pixel-buffer.js
	Version:	1.2
	Purpose:	NCS Pixel Buffer API
	Author:		Dave Wellsted
	Company:	NyteOwl Computer Software
	Updated:	2017-NOV-11
	
	NOTES:
	
	1) This creates a memory array for a pixel map
	2) Uses ECMA6/HTML5/CSS3 Features
	3) Allows for rendering to HTML <canvas> using 2D context

*/

Project.register('pixel-buffer.js')

const PixelBuffer = {
	// Extracts the red channel from an integer ARGB pixel value
	getRed: function(pel) {
		return ((parseInt(pel)>>16)&255)
	},
	// Extracts the green channel from an integer ARGB pixel value
	getGrn: function(pel) {
		return ((parseInt(pel)>>8)&255)
	},
	// Extracts the blue channel from an integer ARGB pixel value
	getBlu: function(pel) {
		return (parseInt(pel)&255)
	},
	// Composes an HTML color value from an integer ARGB pixel value
	HTMLColorFromPixel: function(pel) {
		const pb = PixelBuffer
		return (
			pb.makeHTMLColor(
				pb.getRed(pel),
				pb.getGrn(pel),
				pb.getBlu(pel)
			)
		)
	},
	// Extracts discrete r,g,b channels from an integer ARGB pixel value
	parsePixel: function(pel) {
		const pb = PixelBuffer
		return ({
			'r': pb.getRed(pel),
			'g': pb.getGrn(pel),
			'b': pb.getBlu(pel)
		})
	},
	// Composes an integer ARGB value from discrete r,g,b values
	makePixel: function(r,g,b) {
		return (
			((parseInt(r)&255)<<16)
			|((parseInt(g)&255)<<8)
			|(parseInt(b)&255)
		)
	},
	// Composes an HTML color value from discrete r,g,b values
	makeHTMLColor: function(r,g,b) {
		function hex(n) {
			return (
				(n>15)?
				n.toString(16):
				'0'+n.toString(16)
			)
		}
		return `#${hex(r&255)}${hex(g&255)}${hex(b&255)}`
	},
	// Verifies that the argument contains a valid HTML color value
	isHTMLColor: function(c) {
		return (
			(c.length<7)?false:
			(c[0]!=='#')?false:
			(typeof c === 'string')
		)
	},
	// Extracts discrete r,g,b channels from an HTML color value
	parseHTMLColor: function(clr) {
		return (c=>{
			const pb = PixelBuffer
			const decode = (index=>{
				return parseInt(`0x${c.substr(index,2)}`,16)
			})
			return pb.isHTMLColor(c)?({
				'r' : decode(1),
				'g' : decode(3),
				'b' : decode(5)
			}):({
				'r' : 0,
				'g' : 0,
				'b' : 0
			})			
		})(clr)
	},
	// Composes an integer ARGB pixel value from an HTML color value
	pixelFromHTMLColor: function(clr) {
		const pb = PixelBuffer
		return (o=>{
			return pb.makePixel(o.r,o.g,o.b)
		})(pb.parseHTMLColor(clr))
	},
	// Logs class info to the browser's console 
	announce: function() {
		console.log('PixelBuffer 1.1 API loaded')
		return this
	},
	// Creates an uninitialized instance of a pixel buffer object
	create: function() {
		return {
			setSize: function(w,h,echo) {
				if ('function'===typeof echo) {
					echo(`setSize(${w},${h})`)
					return this
				}
				function clip(n) {
					const v=Math.floor(n);
					return (
						(v<1)?1:
						(v>1024)?1024:
						(isFinite(v)?v:1)
					)
				}
				this.width  = clip(w)
				this.height = clip(h)
				this.data = []
				for (var i=0; i<this.height; i++) {
					this.data.push(new Uint32Array(this.width))
				}
				return this
			},
			getPixel: function(x,y,echo) {
				if ('function'===typeof echo) echo(
					`getPixel(${x},${y})`			
				)
				x = parseInt(x) % this.width
				x = (x<0)?(x+this.width):x
				y = parseInt(y) % this.height
				y = (y<0)?(y+this.height):y
				return this.data[y][x]
			},
			putPixel: function(x,y,pel,echo) {
				if ('function'===typeof echo) {
					echo(`putPixel(${x},${y},${pel})`)
					return this
				}
				x = parseInt(x) % this.width
				x = (x<0)?(x+this.width):x
				y = parseInt(y) % this.height
				y = (y<0)?(y+this.height):y
				this.data[y][x] = (parseInt(pel)&0xFFFFFF)
				return this
			},
			fill: function(pel,echo) {
				pel = (parseInt(pel)&0xFFFFFF);
				if ('function'===typeof echo) {
					echo(`fill(${pel})`)
					return this
				}
				for (var i=0; i<this.height; i++) {
					this.data[i].fill(pel)
				}
				return this
			},
			randomize: function(count,echo) {
				if ('function'===typeof echo) {
					echo(`randomize(${count})`)
					return this
				}
				for (var i=0; i<count; i++) {
					this.putPixel(
						this.width*Math.random(),
						this.height*Math.random(),
						PixelBuffer.makePixel(
							255*Math.random(),
							255*Math.random(),
							255*Math.random()
						),
						echo
					)
				}
				return this
			},
			pixelCount: function(echo) {
				if ('function'===typeof echo) {
					echo(`pixelCount()`)
					return this
				}
				return (this.height * this.width);
			},
			center: function(echo) {
				if ('function'===typeof echo) {
					echo(`center()`)
					return this
				}
				return {
					'x': (Math.floor(0.5*this.width)),
					'y': (Math.floor(0.5*this.height))
				}
			},
			size: function(echo) {
				if ('function'===typeof echo) {
					echo(`size()`)
					return this
				}
				return {
					'w': this.width,
					'h': this.height
				}
			},
			render: function(canvas,x,y,echo) {
				if ('function'===typeof echo) {
					echo(`render(${canvas},${x},${y})`)
					return this
				}
				if (canvas instanceof HTMLCanvasElement) {
					const gfx = canvas.getContext('2d')
					const w = this.width
					const h = this.height
					gfx.beginPath()
					for (var i=0; i<h; i++) {
						let i_i=i+i;
						for (var j=0; j<w; j++) {
							gfx.fillStyle = (
								PixelBuffer
								.HTMLColorFromPixel(this.data[i][j])
							)
							gfx.fillRect(
								x+j+j,
								y+i_i,
								2,
								2
							)
						}
					}
				}
				else {
					throw 'Invalid canvas argument'
				}
			},
			renderSmall: function(canvas,x,y,echo) {
				if ('function'===typeof echo) {
					echo(`render(${canvas},${x},${y})`)
					return this
				}
				if (canvas instanceof HTMLCanvasElement) {
					const gfx = canvas.getContext('2d')
					const w = this.width
					const h = this.height
					gfx.beginPath()
					for (var i=0; i<h; i++) {
						for (var j=0; j<w; j++) {
							gfx.fillStyle = (
								PixelBuffer
								.HTMLColorFromPixel(this.data[i][j])
							)
							gfx.fillRect(x+j,y+i,1,1)
						}
					}
				}
				else {
					throw 'Invalid canvas argument'
				}
			}
		}
	},
	// Creates and initializes an instance of a pixel buffer object
	createEx: function(w,h) {
		return PixelBuffer.create().setSize(w,h)
	}
}

// PixelBuffer.announce()


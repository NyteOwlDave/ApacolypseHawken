
/*

  App.js -- the game application logic

  Author:   Dave Wellsted, NyteOwl Computer Software
  Updated:  2017-NOV-12
  
*/

Project.register('app.js')

const App = {
  // Loaded sound effects (for P5)
  sounds: {
    laser: null,
    proton: null,
    boom: null,
    hyperdrive: null,
    newlife: null,
    theme: null,
    winner: null
  },
  // True when game is in play
	inplay: false,
  // Number of ships remaining
	lives: 3,
  // Player's score
	score: 0,
  // Rounds which have been fired
  rounds: [],
  // Explosions in progress
  booms: [],
  // Active rounds from player
  myRounds: 0,
  // Active rounds from enemies
  theirRounds: 0,
  // Array of 7-segment dissplay digits
  digits: null,
  // Pixels under the lives canvas
  underlives: null,
  // Prevent restart for a little while
  locked: false,
  // Pause during game play
  paused: false,
  // Prevent dying twice from successive hits
  shipHit: false,
  // Next level required for an extra ship
  nextLevel: 0,
  // Initialization
	init: function() {
		console.log('Initializing...')
    Kaboom.createExplosions()
    App.digits = SevenSegmentDisplay.createDigits(null)
    const g = idLivesCanvas.getContext('2d')
    App.underlives = g.getImageData(
      0, 0, idLivesCanvas.width, idLivesCanvas.height
    )
    App.gameReset()
	},
  // Deal with starting over
  gameReset: function() {
		const ws = window.innerWidth
		const hs = window.innerHeight
    idGameOver.style.visibility = 'hidden'
    idWinner.style.visibility = 'hidden'
		let w, h
		Sprite.initShip(idHawken)
		w = idHawken.naturalWidth
		h = idHawken.naturalHeight
		Sprite.move(idHawken,(ws-w)*0.5,(hs-h)*0.5)
    App.spawnEnemy(idEnemy1)
    App.spawnEnemy(idEnemy2)
    App.spawnEnemy(idEnemy3)
		App.lives = 3    
    App.showLives()
		App.score = 0
    App.showScore()
    App.showHealth()
    App.nextLevel = 7500
    App.paused = false
    App.inplay = true
  },
  // Deal with game over condition
  gameOver: function() {
    App.locked = true
    App.inplay = false
    const w1 = window.innerWidth
    const h1 = window.innerHeight
    const w2 = idGameOver.naturalWidth
    const h2 = idGameOver.naturalHeight
    const x = (w1-w2)/2
    const y = (h1-h2)/2
    idGameOver.style.left = x+'px'
    idGameOver.style.top  = y+'px'
    idGameOver.style.visibility = 'visible'
    playThemeMusic()
    window.setInterval(function(){App.locked=false},5000)
  },
  // Deal with game won condition
  youWin: function() {
    App.locked = true
    App.inplay = false
    const w1 = window.innerWidth
    const h1 = window.innerHeight
    const w2 = idWinner.naturalWidth
    const h2 = idWinner.naturalHeight
    const x = (w1-w2)/2
    const y = (h1-h2)/2
    idWinner.style.left = x+'px'
    idWinner.style.top  = y+'px'
    idWinner.style.visibility = 'visible'
    playWinnerMusic()
    window.setInterval(function(){App.locked=false},5000)
  },
  // Update ship positions
	moveShips: function() {
    if (keyIsDown(76)) {
      idHawken.gameState.angleSpeed += 0.077
      if (idHawken.gameState.angleSpeed > 5) {
        idHawken.gameState.angleSpeed = 5
      }
    }
    if (keyIsDown(74)) {
      idHawken.gameState.angleSpeed -= 0.077
      if (idHawken.gameState.angleSpeed < -5) {
        idHawken.gameState.angleSpeed = -5
      }
    }
    if (Math.abs(idHawken.gameState.angleSpeed) > 0.0001) {
      idHawken.gameState.angleSpeed *= 0.99
    }
    else {
      idHawken.gameState.angleSpeed = 0
    }
    if (keyIsDown(73)) {
      idHawken.gameState.thrust += 0.1
      if (idHawken.gameState.thrust > 1) {
        idHawken.gameState.thrust = 1
      }
    }
    if (keyIsDown(75)) {
      idHawken.gameState.thrust -= 0.1
      if (idHawken.gameState.thrust < -0.1) {
        idHawken.gameState.thrust = -0.1
      }
    }
    idHawken.gameState.thrust *= 0.99
    App.calcEnemyMovement(idEnemy1)
    App.calcEnemyMovement(idEnemy2)
    App.calcEnemyMovement(idEnemy3)
    App.moveShip(idHawken)
    App.moveShip(idEnemy1)
    App.moveShip(idEnemy2)
    App.moveShip(idEnemy3)
	},
  // Update the specified ship's position
	moveShip: function(e) {
    let a,dx,dy
    e.gameState.angle += e.gameState.angleSpeed
		e.gameState.angle %= 360
		Sprite.rotate(e, e.gameState.angle)
    e.gameState.speed += e.gameState.thrust
		if (e.gameState.speed > 4) {
      e.gameState.speed = 4
    }
		if (e.gameState.speed < -1) {
      e.gameState.speed = -1
    }
    e.gameState.speed *= 0.99
    if (Math.abs(e.gameState.speed)>0.001) {
      const w = window.innerWidth  + 120
      const h = window.innerHeight + 120
      a = (e.gameState.angle-90)*Math.PI/180
      dx = e.gameState.speed * Math.cos(a)
      dy = e.gameState.speed * Math.sin(a)
      e.gameState.x += dx
      e.gameState.y += dy
      if (e.gameState.x < -200) e.gameState.x = -200
      if (e.gameState.y < -200) e.gameState.y = -200
      if (e.gameState.x > w) e.gameState.x = w
      if (e.gameState.y > h) e.gameState.y = h
      Sprite.move(e, e.gameState.x, e.gameState.y)
    }
  },
  // Navigation logic for a single foe
  calcEnemyMovement: function(foe) {
      const xh = idHawken.gameState.x
      const yh = idHawken.gameState.y
      const xf = foe.gameState.x
      const yf = foe.gameState.y
      let xd = xh - xf
      let yd = yh - yf
      const k = 1 / Math.sqrt(xd*xd + yd*yd)
      xd *= k
      yd *= k
      const a1 = Math.atan2(yd, xd)*180/Math.PI
      const a2 = foe.gameState.angle-90
      const ad = a1-a2
      const as = (ad<0)?-1:(ad>0)?1:0
      foe.gameState.angleSpeed = as * (Math.random() * 0.5 + 0.5)
      if (Math.abs(ad)<45) {
        foe.gameState.thrust += 1
        if (foe.gameState.thrust > 2) {
          foe.gameState.thrust = 2
        }
      }
      else {
        foe.gameState.thrust -= 0.05
        if (foe.gameState.thrust < -0.5) {
          foe.gameState.thrust = -0.5
        }
      }
  },
  // Update positions of active rounds
	moveRounds: function() {
    App.rounds.forEach(e=>{
      let state = e.gameState
      state.x += 11*state.dx
      state.y += 11*state.dy
      Sprite.move(e,state.x,state.y)
    })
		const ws = window.innerWidth-16
		const hs = window.innerHeight-16
    const dead = []
    App.rounds.forEach(e=>{
      let state = e.gameState
      let x = state.x
      let y = state.y
      if ((x<0)||(x>=ws)||(y<0)||(y>=hs)) {
        dead.push(e)
      }
    })
    dead.forEach(e=>{
      App.removeRound(e)
    })
	},
  // Give enemies a chance to fire rounds
  fireRounds: function() {
    const foe = [
      idEnemy1, idEnemy2, idEnemy3
    ]
    foe.forEach(e=>{
      let state = e.gameState
      let type = state.type
      let chance = 1/(50*(12 - type))
      if (Math.random() < chance) {
        const pt = App.fireFromEnemy(e)
      }
    })
  },
  // Detect anything hit by rounds
	detectHits: function() {
    const hits = []
    let dx,dy,k,pt
    App.rounds.forEach(e=>{
      let mx = e.gameState.x + 8
      let my = e.gameState.y + 8
      if (e.gameState.type===1) {
        pt = App.getCenterPoint(idEnemy1)
        dx = mx - pt.x
        dy = my - pt.y
        k = dx*dx+dy*dy
        if (k<1500) {
          hits.push({
            hit: idEnemy1,
            rnd: e
          })
        }
        pt = App.getCenterPoint(idEnemy2)
        dx = mx - pt.x
        dy = my - pt.y
        k = dx*dx+dy*dy
        if (k<1500) {
          hits.push({
            hit: idEnemy2,
            rnd: e
          })
        }
        pt = App.getCenterPoint(idEnemy3)
        dx = mx - pt.x
        dy = my - pt.y
        k = dx*dx+dy*dy
        if (k<1500) {
          hits.push({
            hit: idEnemy3,
            rnd: e
          })
        }
      }
      else {
        pt = App.getCenterPoint(idHawken)
        dx = mx - pt.x
        dy = my - pt.y
        k = dx*dx+dy*dy
        if (k<1500) {
          hits.push({
            hit: idHawken,
            rnd: e
          })
        }
      }
    })
    hits.forEach(h=>{
      App.detonate(h.rnd, h.hit)
    })
	},
  // Fire ship's forward laser
  fireForward: function() {
    const a = (idHawken.gameState.angle-90)*Math.PI/180
    const dx = Math.cos(a)
    const dy = Math.sin(a)
    const pt = App.getCenterPoint(idHawken)
    App.fire(1,pt.x,pt.y,dx,dy)
    App.playSound(App.sounds.laser)
  },
  // Fire ship's computer aimed laser
  fireAtEnemy: function() {
    const pt = App.getCenterPoint(idHawken)
    const fv = App.getFiringVector()
    App.fire(1,pt.x,pt.y,fv.dx,fv.dy)
    App.playSound(App.sounds.laser)
  },
  // Fire one round from specified enemy
  fireFromEnemy: function(foe) {
    const pt = App.getCenterPoint(foe)
    const fv = App.getFoeFiringVector(foe)
    App.fire(2,pt.x,pt.y,fv.dx,fv.dy)
    App.playSound(App.sounds.photon)
  },
  // Fire a round (core function)
  fire: function(type,x,y,dx,dy) {
    const img = document.createElement('img')
    img.setAttribute('class','round')
    img.setAttribute('src','art/round'+type+'.png')
    img.gameState = {
      x  : x,
      y  : y,
      dx : dx,
      dy : dy,
      type: type
    }
    Sprite.move(img,x,y)
    document.body.appendChild(img)
    if (type===1) {
      // Sprite.rotate(img,Math.atan2(dy,dx)*180/Math.PI)
      App.myRounds++
    }
    else {
      App.theirRounds++
    }
    App.rounds.push(img)
  },
  // Detonate a round that hit something
  detonate: function(rnd,hit) {
    App.removeRound(rnd)
    if (hit===idHawken) {
      idHawken.gameState.health -= 3*Math.floor(5*Math.random()+0.5)
      App.showHealth()
      if (idHawken.gameState.health < 1) {
        App.explodeHawken(rnd)
      }
      return
    }
    App.newBoom(rnd)
    Sprite.randomEnemy(hit)
    App.score += 5 * hit.gameState.type
    if (App.score>=100000) {
      App.youWin()
      return
    }
    if (App.score>=App.nextLevel) {
      App.lives += 1
      App.nextLevel += 4000
      App.showLives()
      App.playSound(App.sounds.newlife)
      App.showScore()
      return
    }
    App.playSound(App.sounds.boom)
    App.showScore()
  },
  // Generate a new explosion animated sprite
  newBoom: function(rnd) {
    const exp = Kaboom.newExplosion(rnd.gameState.x+8,rnd.gameState.y+8)
    App.booms.push(exp)
  },
  // Deduct one ship from player
  deductLife: function() {
    App.lives -= 1
    App.showLives()
    if (App.lives < 1) {
      App.gameOver()
    }
    else {
      idHawken.gameState.health = 100
      App.showHealth()
      idHawken.style.visibility = 'hidden'
      window.setTimeout(
        function(){App.doHyperspace()},2500)
    }
    App.shipHit = false
  },
  // Explode the player's ship
  explodeHawken: function(rnd) {
    if (App.shipHit) {return}
    App.shipHit = true
    App.newBoom(rnd)
    App.playSound(App.sounds.boom)
    window.setTimeout(function(){App.deductLife()},400) 
  },
  // Update display of ships remaining
  showLives: function() {
    const g = idLivesCanvas.getContext('2d')
    const w1 = idLivesCanvas.width
    const w2 = 32
    idLivesCanvas.style.left = (window.innerWidth - w1 - 4)+'px'
    g.putImageData(App.underlives,0,0)
    let x = w1 - w2 - 20
    let n
    for (n=0; n<App.lives; n++) {
      g.drawImage(idReserve,x,2)
      x -= w2
    }
  },
  // Update diusplay of ship's health
  showHealth: function() {
    const ww = window.innerWidth
    const wh = window.innerHeight
    idHealthCanvas.width = 100
    idHealthCanvas.height = 20
    idHealthCanvas.style.left = '4px'
    idHealthCanvas.style.top = (wh - 40)+'px'
    idLogo.style.left = (ww - idLogo.naturalWidth - 4)+'px'
    idLogo.style.top = idHealthCanvas.style.top 
    let gradient, x, w
    let level = idHawken.gameState.health
    const g = idHealthCanvas.getContext('2d')
    g.fillStyle = 'black'
    g.fillRect(0,0,100,20)
    if (level > 50) {
      w = level-50
      x = 50 - w
      gradient = g.createLinearGradient(0,0,50,0);
      gradient.addColorStop(0,'green');
      gradient.addColorStop(1,'yellow');
      g.fillStyle = gradient;
      g.fillRect(x,0,w,20);
      level = 50
    }
    w = level
    x = 100 - w
    gradient = g.createLinearGradient(50,0,100,0);
    gradient.addColorStop(0,'yellow');
    gradient.addColorStop(1,'red');
    g.fillStyle = gradient;
    g.fillRect(x,0,w,20);
    g.strokeStyle = 'navy'
    g.beginPath()
    g.rect(0,0,100,20);
    g.stroke()
  },
  // Update display of player's score
  showScore: function() {
    SevenSegmentDisplay.drawDigits(
      idScoreCanvas,
      5, 5,
      App.digits,
      App.score
    )
  },
  // Remove a dead round
  removeRound: function(rnd) {
    if (rnd.parentElement === document.body) {
      document.body.removeChild(rnd)
    }
    const keep = []
    App.rounds.forEach(e=>{
      if (e!==rnd) keep.push(e)
    })
    App.rounds = keep
    if (rnd.gameState.type===1) {
      App.myRounds--
    }
    else {
      App.theirRounds--
    }
    delete rnd
  },
  // Spawn a new enemy
  spawnEnemy: function(e) {
		Sprite.randomEnemy(e)
		e.gameState.angleSpeed = Vec.rnd()-0.5
  },
  // Do hyperspace logic
  doHyperspace: function() {
    const e = idHawken
    const w = window.innerWidth  - e.naturalWidth
    const h = window.innerHeight - e.naturalHeight
    const x = Math.floor(w*Math.random()+0.5)
    const y = Math.floor(h*Math.random()+0.5)
    e.gameState.angleSpeed = 0
    e.gameState.thrust = 0
    e.gameState.speed = 0
    e.gameState.angle = Math.floor(360*Math.random()) - 180
    Sprite.move(e,x,y)
    e.style.visibility = 'visible'
    App.playSound(App.sounds.hyperdrive)
  },
  // Compose relative URI for sound effect
  composeSoundUri: function(name) {
    return 'audio/'+name+'.mp3'
  },
  // Play a sound (P5)
  playSound: function(snd,vol) {
    if (vol!==undefined) snd.setVolume(vol);
    else snd.setVolume(0.1);
    snd.play();
  },
  // Get centerpoint for a sprite
  getCenterPoint: function(e) {
    const rc = {
      x : parseInt(e.style.left),
      y : parseInt(e.style.top),
      w : e.naturalWidth,
      h : e.naturalHeight
    }
    return {
      x: (rc.x + rc.w/2),
      y: (rc.y + rc.h/2)
    }
  },
  // Get computer aimed firing vector
  getFiringVector: function() {
    const pth = App.getCenterPoint(idHawken)
    const pt1 = App.getCenterPoint(idEnemy1)
    const pt2 = App.getCenterPoint(idEnemy2)
    const pt3 = App.getCenterPoint(idEnemy3)
    const erx = Math.floor(24*Math.random())-48
    const ery = Math.floor(24*Math.random())-48
    let dx, dy, d1, d2, d3, k
    dx = pth.x - pt1.x
    dy = pth.y - pt1.y
    d1 = dx*dx + dy*dy
    dx = pth.x - pt2.x
    dy = pth.y - pt2.y
    d2 = dx*dx + dy*dy
    dx = pth.x - pt3.x
    dy = pth.y - pt3.y
    d3 = dx*dx + dy*dy
    if (d1 < d2) {
      if (d1 < d3) {
        dx = pt1.x - pth.x + erx
        dy = pt1.y - pth.y + ery
        k = 1 / Math.sqrt(d1)
      }
      else  {
        dx = pt3.x - pth.x + erx
        dy = pt3.y - pth.y + ery
        k = 1 / Math.sqrt(d3)
      }
    }
    else if (d2 < d3) {
      dx = pt2.x - pth.x + erx
      dy = pt2.y - pth.y + ery
      k = 1 / Math.sqrt(d2)
    }
    else  {
      dx = pt3.x - pth.x + erx
      dy = pt3.y - pth.y + ery
      k = 1 / Math.sqrt(d3)
    }
    return {
      dx: k*dx,
      dy: k*dy
    }
  },
  // Get a foe's firing vector
  getFoeFiringVector: function(e) {
    const pth = App.getCenterPoint(idHawken)
    const pt1 = App.getCenterPoint(e)
    const erx = Math.floor(24*Math.random())-48
    const ery = Math.floor(24*Math.random())-48
    let dx, dy, d, k
    dx = pth.x - pt1.x + erx
    dy = pth.y - pt1.y + ery
    d = dx*dx + dy*dy
    k = 1 / Math.sqrt(d)
    return {
      dx: k*dx,
      dy: k*dy
    }  
  },
  // Animate explosion sprites
  animateBooms: function() {
    const dead = []
    const alive = []
    App.booms.forEach(b=>{
      if (b.i >= Kaboom.EXPLODE_FRAMES) {
        dead.push(b)
      }
      else {
        alive.push(b)
        Kaboom.drawFrame(b)
      }
      b.i += 1
    })
    dead.forEach(b=>{
      Kaboom.removeCanvas(b)
    })
    delete dead
    delete App.booms
    App.booms = alive
  }
}


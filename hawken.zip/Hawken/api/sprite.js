
/*

  sprite.js -- sprite functions
  Dave Wellsted, NyteOwl Computer Software
  2017-NOV-05
  
*/

Project.register('sprite.js')

const Sprite = {
  move: function(e,x,y) {
    e.style.left = x+'px';
    e.style.top = y+'px';
    e.gameState.x = x
    e.gameState.y = y
  },
  rotate: function(e) {
    const degrees = e.gameState.angle||0
    e.style.transform = 'rotate(' + degrees + 'deg)'
  },
  scale: function(e) {
    const k = e.gameState.scale||0
    e.style.transform = 'scale(' + k + ',' + k + ')'
  },
  initShip: function(e) {
    e.gameState = {
			x: 0,
			y: 0,
      health: 100,
      scale: 1,
      angle: 0,
			angleSpeed: 0,
			thrust: 0,
			speed: 0
		}
  },
  randomEnemy: function(e) {
    const type = 1 + Math.floor(10*Math.random() + 0.5)
    e.setAttribute('src', 'art/enemy'+type+'.png')
		const ws = window.innerWidth
		const hs = window.innerHeight
    let x, y
    Sprite.initShip(e)
    const area = Math.floor(Math.random()*4+0.5)
    switch (area) {
      case 0:
        x = -200
        y = Vec.srnd(hs)
        break;
      case 1:
        x = ws + 120
        y = Vec.srnd(hs)
        break;
      case 2:
        x = Vec.srnd(ws)
        y = -200
        break;
      case 2:
        x = Vec.srnd(ws)
        y = hs + 120
        break;
      default:
        x = Vec.srnd(ws-e.naturalWidth)
        y = Vec.srnd(hs-e.naturalHeight)
        //App.playSound(App.sounds.hyperdrive)
        break;
    }
		Sprite.move(e,x,y)
		e.gameState.angle = Vec.srnd(360)
    e.gameState.type = type
  }
}

